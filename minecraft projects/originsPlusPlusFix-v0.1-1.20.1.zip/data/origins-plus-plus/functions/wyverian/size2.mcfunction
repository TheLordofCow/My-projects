scale set pehkui:base 1.5
scale persist set true