package gramerkyleproject1;

public class Members {
    
    private String customerName;
    private boolean isPremium;
    private int monthJoined;
    private int yearJoined;
    private int isMonthPaid; //-1 for not a premium, 0 for not paid, 1 for paid
    private double moneySpent; //only counts for products purchased from the library, does NOT include subscription money
    //i tried to make a formula that calculates # spent on sub costs and display it in the member info function, but figuring out that formula wasnt a priority
    private String paymentMethod;
    
    // Basic creation of an object named "Members" containing 7 fields with necessary getters and setters and toString
    // contains 2 constructors
    // "premuium member" constructor takes 6 of the fields and sets premium field to true
    // "regular member" constructor takes only 2 of the fields because most of the Member object fields only apply to premium member data
    
    public Members(String customerName, int monthJoined, int yearJoined, int isMonthPaid, double moneySpent, String paymentMethod) {
        this.customerName = customerName;
        this.isPremium = true;
        this.monthJoined = monthJoined;
        this.yearJoined = yearJoined;
        this.isMonthPaid = isMonthPaid;
        this.moneySpent = moneySpent;
        this.paymentMethod = paymentMethod; 
    }
    
    public Members(String customerName, double moneySpent) {
        this.customerName = customerName;
        this.isPremium = false;
        this.monthJoined = 0;
        this.yearJoined = 0;
        this.isMonthPaid = -1;
        this.moneySpent = moneySpent;
        this.paymentMethod = "N/A"; 
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public boolean getIsPremium() {
        return isPremium;
    }
    
    public int getMonthJoined() {
        return monthJoined;
    }
    
    public int getYearJoined() {
        return yearJoined;
    }
    
    public int getIsMonthPaid() {
        return isMonthPaid;
    }
    
    public double getMoneySpent() {
        return moneySpent;
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    public void setIsPremium(boolean isPremium) {
        this.isPremium = isPremium;
    }
    
    public void setMonthJoined(int monthJoined) {
        this.monthJoined = monthJoined;
    }
    
    public void setYearJoined(int yearJoined) {
        this.yearJoined = yearJoined;
    }
    
    public void setIsMonthPaid(int isMonthPaid) {
        this.isMonthPaid = isMonthPaid;
    }
    
    public void setMoneySpent(double moneySpent) {
        this.moneySpent = moneySpent;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    @Override
    public String toString() {
        return "Members{" + "customerName=" + customerName + ", isPremium=" + isPremium + ", monthJoined=" + monthJoined + ", yearJoined=" + yearJoined + ", isMonthPaid=" + isMonthPaid + ", moneySpent=" + moneySpent + ", paymentMethod=" + paymentMethod + '}';
    }
    
}
