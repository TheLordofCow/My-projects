package gramerkyleproject1;

public class Inventory {
    
    private String mediaName;
    private String authorName;
    private String mediaType;
    private String genre;
    private int releaseYear;
    private int stockCount;
    private double priceTag;
    
    // Basic creation of an object named "Inventory" containing 7 fields with necessary getters and setters and toString
    // only contains 1 constructor that accepts all 7 fields
    
    public Inventory (String mediaName, String authorName, String mediaType, String genre, int releaseYear, int stockCount, double priceTag) {
        this.mediaName = mediaName;
        this.authorName = authorName;
        this.mediaType = mediaType;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.stockCount = stockCount;
        this.priceTag = priceTag;
    }
    
    public String getMediaName() {
        return mediaName;
    }
    
    public String getAuthorName() {
        return authorName;
    }
    
    public String getMediaType() {
        return mediaType;
    }
    
    public String getGenre() {
        return genre;
    }
    
    public int getReleaseYear() {
        return releaseYear;
    }
    
    public int getStockCount() {
        return stockCount;
    }
    
    public double getPriceTag() {
        return priceTag;
    }
    
    public void setMediaName(String mediaName) {
        this.mediaName = mediaName;
    }
    
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    
    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }
    
    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }
    
    public void setStockCount(int stockCount) {
        this.stockCount = stockCount;
    }
    
    public void setPriceTag(double priceTag) {
        this.priceTag = priceTag;
    }

    @Override
    public String toString() {
        return "Inventory{" + "mediaName=" + mediaName + ", authorName=" + authorName + ", mediaType=" + mediaType + ", genre=" + genre + ", releaseYear=" + releaseYear + ", stockCount=" + stockCount + ", priceTag=" + priceTag + '}';
    }
    
}
