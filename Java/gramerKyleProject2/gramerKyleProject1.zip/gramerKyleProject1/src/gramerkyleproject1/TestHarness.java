package gramerkyleproject1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestHarness {
    
    //main method calls library class methods to execture high level functions
    public static void main(String[] args) {
        
        int loop = 0; //hold user input menu until library program is exited with a "6" input
        int num = 0; // user input for switch case functions
        
        Library library = new Library(); //instantiate library class to populate array lists and use the methods in library class
        Scanner sc = new Scanner(System.in);
        
        //loop all library functions until exited
        while (loop != 6) {
            System.out.println("Please select from the following menu of options, by typing a number:");
            System.out.println("\t 1. Register a new member");
            System.out.println("\t 2. View stock");
            System.out.println("\t 3. Complete a purchase");
            System.out.println("\t 4. Request an item");
            System.out.println("\t 5. View member list");
            System.out.println("\t 6. Exit");
            
            while (true) { // get proper input
                try {
                    num = sc.nextInt();
                    sc.nextLine();
                    break;
                }
                catch (InputMismatchException e) {
                    System.out.println("Sorry, but you need to enter a 1, 2, 3, 4, 5 or a 6");
                    sc.nextLine();
                }
            }
            loop = num; //check to see if user exited before going to exit switch case or etc
            switch (num) {
            case 1: //function 1: register a regular, or premium member
                int numMember;
                System.out.println();
                System.out.println("Would you like to register as a free member, or a premium member to get exclusive benefits for a $5 monthly fee?");
                System.out.println("Enter 1 to register as free, 2 for premium");
                while (true) { // get user input
                    try {
                        numMember = sc.nextInt();
                        if (numMember == 1 || numMember == 2) {
                            break;
                        }
                        else {
                            System.out.println("Please enter a number 1 or 2.");
                        }
                    }
                    catch (InputMismatchException e) {
                        System.out.println("Please enter a number 1 or 2.");
                        sc.nextLine();
                    }
                }
                switch (numMember) { //after valid input is recieved, gather data to create a regular, or a premium member
                    case 1: 
                        sc.nextLine();
                        System.out.println("Please enter your name");
                        String regName = sc.nextLine();
                        library.addMemberFree(regName, 0.0);
                        System.out.println("Welcome, "+regName+"! Thank you for joining the library membership program.");
                        System.out.println();
                        break;
                    case 2:
                        sc.nextLine();
                        System.out.println("Please enter your name");
                        String premName = sc.nextLine();
                        System.out.println("How would you like to pay for your first month of membership? (Credit/Debit/Cash/Check)");
                        String payType = sc.nextLine();
                        library.addMemberPremium(premName, 10, 2021, 1, 0.0, payType);//could use a date import so that this is accurate outside of oct 2021, but eh
                        System.out.println("Welcome, "+premName+"! Thank you for joining the premium library membership program!");
                        System.out.println();
                        break;
                    }
                break;
            case 2: //function 2: show the library's official and requested stock. good for troubleshooting and browsing for purchase decisions
                System.out.println();
                library.showStock();
                break;
            case 3: //function 3: make a purchase
                char choice = 'y'; //loop function after failed or successful purchases
                int stockChoice;
                int stockQuantity;
                boolean cancelOrder = false; // skip to end of purcahse function if a stock of 0 is entered for an item, or if the item is out of stock
                boolean orderSucc = true; // validates successful purchase
                String memberPurchase = "OooOoh SeCrEt Code11!!1!"; // used for multiple item purchases. no need to ask for a user name on the second purchase if
                                                                    // it was given for the first item purchased
                while (choice == 'Y' || choice == 'y') {
                    library.showStockShort(); // abbreviated version of the 2nd function which shows the full stock, this one only shows enough info needed to make a purchase decision
                    System.out.println("Please enter the number of the item you would like to buy (1-9)");
                    while (true) { // item decision validation
                        try {
                            stockChoice = sc.nextInt();
                            sc.nextLine();
                            if (stockChoice > 9 || stockChoice < 1) {
                                System.out.println("That is not a valid item number. Please try again");
                            }
                            else {
                                break;
                            }
                        }
                        catch (InputMismatchException e) {
                            System.out.println("Sorry, but you need to enter a 1, 2, 3, 4, 5, 6, 7, 8 or 9");
                            sc.nextLine();
                        }
                    }
                    System.out.println("You selected "+library.getNameOf(stockChoice)+".");
                    System.out.println("What quantity of this product would you like to buy? ");
                    while (true) { // stock quantity validation
                        try {
                            stockQuantity = sc.nextInt();
                            if (library.getStockOf(stockChoice)==0) {
                                System.out.println("Our apologies, but we are sold out of that product");
                                cancelOrder = true; 
                                break;
                            } //end order if the library is out of stock
                            else if (stockQuantity < 0) {
                                System.out.println("You must enter a whole number amount that is at least 1. Enter 0 to cancel the order for this product.");
                            } //retry input if a negative int is given
                            else if (stockQuantity > library.getStockOf(stockChoice)) {
                                System.out.println("The number entered exceeds our stock count. We only have "+library.getStockOf(stockChoice)+" of that product.");
                            } //retry input if quantity chosen is more than stock available
                            else if (stockQuantity == 0) {
                                cancelOrder = true;
                                break;
                            } //end order if a quantity of 0 is entered
                            else {
                                break;
                            } //continue order if an acceptable quantity is given
                        }
                        catch (InputMismatchException e) {
                            System.out.println("Sorry, but you need to enter a number 1-9.");
                            sc.nextLine();
                        } //retry input if a non-int data type is inputted
                        
                    }
                    if (cancelOrder == false) { // recieve user name once if it has not been recieved for this call of the function
                        if (memberPurchase.equals("OooOoh SeCrEt Code11!!1!")) {
                            System.out.println("What is the name for the user?");
                            memberPurchase = sc.next(); 
                        }
                        orderSucc = library.makePurchase(memberPurchase,stockChoice,stockQuantity); //attempt to make the purchase with given data
                        if (orderSucc) { //successful purchase
                            System.out.println("Purchase complete, thank you "+memberPurchase+". Would you like to make another purchase? (y/n)");
                        }
                        else { //unsuccessful purchase, bad user name given
                            System.out.println("Only registered members may make purchases, and the name you entered could not be found.");
                            System.out.println("Would you like to try and make another purchase? (y/n)");
                            memberPurchase = "OooOoh SeCrEt Code11!!1!"; // allows the name entry to be reached again after a failed name search
                        }
                    }    
                    else { // reached if order is cancelled by user entering 0 quantity or if the library is out of stock of the chosen item
                        System.out.println("Order cancelled. Would you like to make another order? (y/n)");
                    } //continue function loop or exit
                    choice = sc.next().charAt(0);
                    cancelOrder = false; //reset order cancel status
                }
                break;
            case 4: //function 4: request an item. simply constructss an inventory item and adds it to requested inventory array list.
                //no methods do anything with the data in this array list, but it can be viewed with function 2, until the library makes it official stock
                System.out.println("What is the title of the media you are looking for?");
                String reqTitle = sc.nextLine();
                System.out.println("Who is the author?");
                String reqAuth = sc.nextLine();
                System.out.println("What type of media is it? (DVD/CD/Book)");
                String reqType = sc.nextLine();
                library.requestedInventory(reqTitle, reqAuth, reqType);
                System.out.println("Your request has been documented.");
                System.out.println();
                break;
            case 5: //function 5: view member list. good for troubleshooting 
                int x = 123;
                System.out.println("Please enter your employee pin to view this private information."); // employee test would not actually accept any int, but it does 
                while (true) {                                                                          // for the purposes of the assignment
                    try { // user input validation loop simply checks for any int to be entered. security violation time :)
                        x = sc.nextInt();
                        break;
                    }
                    catch(InputMismatchException e) {
                        System.out.println("Your employee code should be an integer ex: '173'");
                        sc.nextLine();
                    } 
                }
                System.out.println("Welcome, Employee #"+x);
                library.showMembers(); //show all objects in memberList array list
                break;
            case 6: // exit library program. Thanks for coming!
                System.out.println("Thank you for using the library services");
                break;
            }
            
        } 
        
    }
    
}
