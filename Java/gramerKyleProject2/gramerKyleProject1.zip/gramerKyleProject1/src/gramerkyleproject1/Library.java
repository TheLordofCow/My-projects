package gramerkyleproject1;

import java.util.ArrayList;

public class Library {
    
    //library class creates 3 arraylists for holding inventory and member objects
    //also populates 2 of the arraylists and contains the necessary methods for the high level "functions" of the library project to work properly
    
    private ArrayList<Inventory> libraryStock = new ArrayList<Inventory>(); //official library stock, inventory objects only
    private ArrayList<Inventory> requestedStock = new ArrayList<Inventory>(); // empty arraylist that can be populated by requested stock during program run. inventory objects
    private ArrayList<Members> memberList = new ArrayList<Members>(); //official member list + will hold members created during program run. members objects only
    
    //populate official stock and member lists
    public Library() {
        libraryStock.add(new Inventory("Avengers: Infinity War", "Marvel Studios", "DVD", "Action/Sci-fi", 2018, 52, 19.99)); // dvd stock
        libraryStock.add(new Inventory("Soul", "Disney-Pixar Studios", "DVD", "Family/Adventure", 2020, 102, 29.99));
        libraryStock.add(new Inventory("Twilight", "Stephenie Meyer", "DVD", "Romance/Fantasy", 2008, 69, 8.99));
       
        libraryStock.add(new Inventory("Donda", "Kanye West", "CD", "Hip-Hop/Gospel", 2021, 92, 7.99)); // cd stock
        libraryStock.add(new Inventory("Certified Lover Boy", "Aubrey Drake Graham", "CD", "Hip-Hop/Rap", 2021, 66, 8.99));
        libraryStock.add(new Inventory("Risk of Rain 2 Soundtrack", "Chris Christodoulou", "CD", "Electronic/Progressive Metal", 2020, 52, 6.99));
        
        libraryStock.add(new Inventory("To Kill a Mockingbird", "Harper Lee", "Book", "Southern Gothic", 1960, 115, 9.99)); // book stock
        libraryStock.add(new Inventory("Twilight", "Stephenie Meyer", "Book", "Romance/Fantasy", 2005, 44, 13.99));
        libraryStock.add(new Inventory("Remembering the Kanji", "James Heisig", "Book", "Language Learning", 1977, 12, 24.99));
        
        memberList.add(new Members("Kyle", 5, 2019, 1, 172.83, "Cash")); // premium members
        memberList.add(new Members("John", 9, 2021, 0, 99.12, "Cash"));
        memberList.add(new Members("Kenny", 1, 2013, 1, 573.09, "Debit"));
        memberList.add(new Members("Jason", 12, 2020, 0, 15.00, "Credit"));
        memberList.add(new Members("Patrick", 3, 2017, 1, 51.30, "Debit"));
        
        memberList.add(new Members("Jackson", 32.07)); // regular members
        memberList.add(new Members("Reece", 70.52));
        memberList.add(new Members("Ethan", 69.69));
        memberList.add(new Members("Jasmine", 7.82));
        memberList.add(new Members("Connor", 113.83)); 
    }
    
    //print method shows all the items in the libraryStock and requestedStock arrayLists
    public void showStock() {
        int x = 0; //ints are used to count how many items are in the lists
        int y =0;
        System.out.println("***LIBRARY STOCK***");
        System.out.println();
        for (int i = 0; i< libraryStock.size(); i++) {
            System.out.println("Item "+(i+1));
            System.out.println("Title: "+libraryStock.get(i).getMediaName());
            System.out.println("Author: "+libraryStock.get(i).getAuthorName());
            System.out.println("Media Type: "+libraryStock.get(i).getMediaType());
            System.out.println("Genre: "+libraryStock.get(i).getGenre());
            System.out.println("Published: "+libraryStock.get(i).getReleaseYear());
            System.out.println("The library has "+libraryStock.get(i).getStockCount()+" copies in stock");
            System.out.println("Retail price: $"+libraryStock.get(i).getPriceTag());
            System.out.println();
            if (libraryStock.get(i).getStockCount() != 0) {
                x++;
            }
        }
        System.out.println("We have "+x+" products for sale at the moment.");
        System.out.println();
        System.out.println("Requested Items:");
        System.out.println();
        for (int j = 0; j<requestedStock.size(); j++) {
            System.out.println("Item "+(j+1));
            System.out.println("Title: "+requestedStock.get(j).getMediaName());
            System.out.println("Author: "+requestedStock.get(j).getAuthorName());
            System.out.println("Media Type: "+requestedStock.get(j).getMediaType());
            System.out.println("Genre, publish date: N/A");
            System.out.println();
            y++;
        }
        System.out.println("We have "+y+" product(s) requested at the moment.");
        System.out.println();
    }
    
    // print method shows all items in the libraryStock, but only shows enough of the fields for a user to make a purchase decision
    public void showStockShort() {
        int x = 0;
        System.out.println("***LIBRARY STOCK***");
        System.out.println();
        for (int i = 0; i< libraryStock.size(); i++) {
            System.out.println("Item "+(i+1));
            System.out.println("Title: "+libraryStock.get(i).getMediaName());
            System.out.println("Author: "+libraryStock.get(i).getAuthorName());
            System.out.println("Media Type: "+libraryStock.get(i).getMediaType());
            System.out.println("The library has "+libraryStock.get(i).getStockCount()+" copies in stock");
            System.out.println("Retail price: $"+libraryStock.get(i).getPriceTag());
            System.out.println();
            if (libraryStock.get(i).getStockCount() != 0) {
                x++;
            }
        }
        System.out.println("We have "+x+" products for sale at the moment.");
        System.out.println();
        
    }
    
    //print method shows all the members in the memberList arrayList
    public void showMembers() {
        int x = 0;
        String premTest = "";
        
        System.out.println("***MEMBER LIST***");
        System.out.println();
        for (int i = 0; i< memberList.size(); i++) {
            System.out.println("Member "+(i+1));
            System.out.println("Member name: "+memberList.get(i).getCustomerName());
            System.out.println("Is this customer premium?: "+memberList.get(i).getIsPremium());
            System.out.println("Month Joined: "+memberList.get(i).getMonthJoined());
            System.out.println("Year Joined: "+memberList.get(i).getYearJoined());
            if (memberList.get(i).getIsMonthPaid()== 1) { //converts the integer "isMonthPaid" field into something more readable
                premTest = "Yes";
            }
            else if (memberList.get(i).getIsMonthPaid()== 0){
                premTest = "No";
            }
            else {
                premTest = "Not a premium member";
            }
            System.out.println("Has this month's fee been paid?: "+premTest);
            System.out.println("Money spent at library: $"+memberList.get(i).getMoneySpent()); //should format this double to 2 decimals
            System.out.println("Payment method used for monthly fees: "+memberList.get(i).getPaymentMethod());
            System.out.println();
            x++;
        }
        System.out.println("We have "+x+" members currently registered");
        System.out.println();
    }
    
    //make purchase method searches for a name in the memberList array that matches the string paramater.
    //if no match is found, change nothing in the arrayLists, return false, and cancel the purchase. if match is found:
    //set the stockCount of the selected item to stock minus num purchased. 
    //set the moneySpent of the user to money spent + product price*product quantity
    public boolean makePurchase(String name, int prodNum, int prodQnty) {
        double price = libraryStock.get(prodNum-1).getPriceTag();
        for(int i = 0; i< memberList.size(); i++) {
            if (name.equalsIgnoreCase(memberList.get(i).getCustomerName())) { // adds $ spent to member of first matching name. I sure hope there are no duplicate customer names :)
                libraryStock.get(prodNum-1).setStockCount(libraryStock.get(prodNum-1).getStockCount()-prodQnty);
                memberList.get(i).setMoneySpent(memberList.get(i).getMoneySpent()+(price * prodQnty)); //sometimes leads to obnoxious decimals. need to format member $ spent double
                return true;
            }
        }
        return false;
    }
    
    //gets name of an item selected by user during the purchase function
    //called to show that the item chosen is indeed what the user is looking for
    public String getNameOf (int item) {
        return libraryStock.get(item-1).getMediaName();
    }
    
    //gets stock of an item selected by user during the purchase function
    //called when user tries to buy a higher quantity of a product than exists
    public int getStockOf(int count) {
        return libraryStock.get(count-1).getStockCount();
    }
    
    //use premium member constructor with given data and add it to memberList array list
    public void addMemberPremium(String name, int month, int year, int due, double spent, String payment) {
        memberList.add(new Members(name, month, year, due, spent, payment));
    }
    
    //use regular member constructor with given data and add it to memberList array list
    public void addMemberFree(String name, double spent) {
        memberList.add(new Members(name, spent));
    }
    
    //use only inventory constructor with given data, and some implied data, and add to requestedStock array list
    //if a user is requesting an item, they are not expected to know the title, author, media type, genre, release year, or the MSRP of the item,
    //so only some of this data is requested until the library can get stock of the item and provide the information within official stock
    public void requestedInventory(String title, String author, String type) {
        requestedStock.add(new Inventory(title, author, type, "N/A", 0, 0, 0.0));
    }
    
}
